# Vinnytsia and Ukraine

Collection of data sets and analyses related to Ukraine in general and Vinnytsia in particular.


# Air Sirens

![Air Sirens in Vinnytsia][air]

![Air Sirens in Vinnytsia-summary][airsum]

[air]:./analysis/report-1/prints/1-cyclogram.png
[airsum]:./analysis/report-1/prints/2-count-duration.png
